# 喜马拉雅 金币提现 · 抢额度工具（Go 纯协议）

从 `喜马拉雅.js`（v3.12）抽出提现链路，用 Go 重写。
**只做提现**：跑任务、扫码绑微信都在 App/`main.py` 侧，不在这份工具里。

## 协议链路

```text
GET  /point-http/account/cash/withdrawConfig   档位 / 余额 / 绑卡状态
POST /point-http/account/cash/reserveQuota     预占额度  <- 抢的就是这里
POST /point-http/account/cash/withdraw         提交提现
GET  /point-http/account/cash                  查余额
```

请求体（信封）：

```text
key  = 16 字符（nanoid 表随机）
data = base64( AES-128-CBC-PKCS7(json, key, IV="0123456789abcedf") )
sk   = base64( RSA-2048/PKCS1v15(pub, key) )
sig  = md5( configId + salt + sk + timestamp_ms + x-tk + uid )
```

请求头：`x-security-config-id / x-timestamp / x-secret-key / x-signature / x-tk / x-nonce`

x-tk 为 XuidSDK ticket，纯算生成（见 `xtk.go`，`-selftest` 可逐字节自检）。

## 平台变体

| 项 | Android | iOS |
| --- | --- | --- |
| configId | 2888001 | 1888001 |
| salt | 7UlJQvyrOitbIcD4 | uoXvlUNciRtS03nk |
| 包名 | com.ximalaya.ting.android | com.gemd.iting |
| 票据前缀 | TAC | TIC |
| u16 来源 | cookie 里的设备 UUID | sha256("xmly-xuid:"+uid) |

## 配置：只要填账号

```bash
cp .env.example .env       # 把 xmly 换成你的 Cookie（每行一条）
./xmly-rush                # 直接跑，常驻挂机
```

像 `喜马拉雅.js` 一样，只认 `xmly`（多行；自动识别 Cookie / 账号#密码）：
也兼容 `XMLYOFF_CK` / `XMLYOFF_APP`，或同目录 `accounts.txt`。

其余全部内置，无需配置：

```text
放量窗口  0,8,12,16,20 点     抢单时长 90s
提前就绪  1.5s               提前发射 放量前 300ms 开火（请求正好卡在点上）
迟到宽限  刚过整点 2 分钟内启动 → 立刻补抢
并发      6 协程/号（档位并发·优先最高）
提现档位  默认提「余额能覆盖的最高档」；多档同时抢，命中低档后再等 0.6s 看更高档
绑定筛查  启动先查绑定状态：没绑微信/支付宝的号不参与提现；每个窗口复查，绑好自动捡回
网络对时  开工即对表（NTP 式采样），每 5 分钟轻量校准，放量前 30s 再对一次
平台变体  从 Cookie 自动识别（1&_device=android / iPhone）
状态文件  _state.json        票据缓存 _wticket.txt（可选）
```

排错用：`-status`（看状态）/ `-once`（立即试）/ `-dry`（只演算不发请求）/ `-only <uid>`（只跑一个号）
诊断：`-probe`（每档各打一发 reserveQuota，看服务端真实返回）/ `-timesync`（看各时间源实测偏移）
自检：`-selftest`（x-tk 逐字节）
`XMLY_VERBOSE=1` 打印服务端原始响应。

## 提现记录与跨零点

成功提现后写入 `_state.json`（日期按**东八区**）：

```json
{
  "607197160": { "date": "2026-10-03", "amount": 1, "orderId": "...", "ts": 1791000000000 }
}
```

判重有两道闸，互相兜底：

1. **本地记录** —— `date == 今天(东八区)` 即视为已提，直接跳过；
   到了第二天日期自然对不上，**自动重新参与**（不需要人工清理）。
2. **服务端口径** —— `withdrawConfig.todayWithdrawCount >= dailyWithdrawLimit` 时跳过，
   零点由服务端归零。

loop 模式下如果**全部账号今天都提完了**，会打印
`今日全部已提，休眠到 MM-DD 00:00:00` 并直接睡到第二天 0 点（提前 30s 唤醒）。
旧记录超过 7 天自动清理。

## 抢额度设计

1. 预热：先拉 `withdrawConfig` 挑候选档位，把每档的 AES + RSA 信封都算好
   （放量瞬间只剩一次 MD5 签名）。
2. 选档：候选 = **已绑卡 + 金额 ≤ 余额**，按「高→低」排序（默认提余额能覆盖的最高档）。
   没绑微信/支付宝的号在启动筛查时就被排开，不浪费任何请求。
3. 对时：`waitUntil` 最后 2 秒切 1ms 轮询，保证放量瞬间就位。
4. 提前 300ms 开火：6 个协程按「最高档拿一半、其余均分」猛打 `reserveQuota`，
   第一波请求正好落在放量瞬间；命中低档后再等 0.6s —— 更高档若同样命中就升档。
5. 按服务端返回分类（`-probe` 实测）：

   | 返回 | 含义 | 动作 |
   | --- | --- | --- |
   | `21112 暂不支持` | 无需预占 | 直接提现 |
   | `995 今日额度已抢完` | 正常竞争 | 继续猛冲 |
   | `995 余额不足` | 该档死掉 | 放弃该档 |
   | 登录/鉴权类 | 账号异常 | 整号停手 |

6. 成交即提现：带 `quotaOrderId` 发 `withdraw`，成功后回读余额；收工打印过程统计。
7. 多账号各自一个协程，互不排队。

额度是限量秒杀，0/8/12/16/20 点整点放量，先到先得。

## 网络对时

额度是**整点秒杀**，本机时钟偏几百毫秒就错过首波。开工先对表（`-timesync` 可单看）：

* 采样两个公开毫秒时间源（京东支付 / 淘宝），每轮记 t0/t1，
  偏移 = (服务端时间 + RTT/2) − t1，多轮取 **RTT 最小**的样本；
* 常驻时每 5 分钟轻量重对，偏移变化 ≥50ms 才提示；
* 等待窗用对时后的时钟：最后 2 秒切 1ms 轮询，放量前 30s 再对一次表；
* 对时结果同样作用于 `x-timestamp` / 签名 / 日期判定（都跟服务端走）。

实测本机时钟慢 ~870ms，对表之后整点判定才靠谱。

## 边界：这里只做提现

跑任务、扫码绑微信都不在这份工具里：

* 绑微信（提现渠道）→ `main.py` WebUI「生成绑定二维码」（或 `dev/pay/` 下的脚本）；
* 金币任务 → App。

本工具只负责：档位放量时**抢额度 → 提交提现 → 记录状态**。
没绑卡的号会直接跳过并提示，绑完卡再跑即可（无需改配置）。

## 自检

```bash
go run . -selftest
# x-tk 自检: MATCH = true
```
