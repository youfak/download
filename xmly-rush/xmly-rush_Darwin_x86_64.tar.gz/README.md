# 喜马拉雅 金币提现 · 抢额度工具（Go 纯协议）

从 `喜马拉雅.js`（v3.12）抽出提现链路，用 Go 重写。
**主流程只做提现**：跑任务、扫码绑微信都在 App/`main.py` 侧，不在这份工具里。
唯一例外是 0 点提现前会自动检查并补签到，避免漏签影响提现。

## 协议链路

```text
GET  /point-http/account/cash/withdrawConfig   档位 / 余额 / 绑卡状态
POST /point-http/account/cash/reserveQuota     预占额度  <- 抢的就是这里
POST /point-http/account/cash/withdraw         提交提现
GET  /point-http/account/cash                  查余额
```

请求体（信封）：

```text
key  = 16 字符（nanoid 表随机）
data = base64( AES-128-CBC-PKCS7(json, key, IV="0123456789abcedf") )
sk   = base64( RSA-2048/PKCS1v15(pub, key) )
sig  = md5( configId + salt + sk + timestamp_ms + x-tk + uid )
```

请求头：`x-security-config-id / x-timestamp / x-secret-key / x-signature / x-tk / x-nonce`

x-tk 为 XuidSDK ticket，纯算生成（见 `xtk.go`，`-selftest` 可逐字节自检）。

0 点提现窗口会在提交 `withdraw` 前检查今日签到；未签到则先用
`incentives/gold_reward` 票据提交 `rewardGoldCoin`，再继续提现。
签到失败只打印告警，仍继续提交 `withdraw`，避免丢掉已经抢到的额度。票据优先读 `_ticket.txt`
（`uid#ticket`），其次读 `XMLYOFF_TICKET`，都没有则现场派生。

## 平台变体

| 项 | Android | iOS |
| --- | --- | --- |
| configId | 2888001 | 1888001 |
| salt | 7UlJQvyrOitbIcD4 | uoXvlUNciRtS03nk |
| 包名 | com.ximalaya.ting.android | com.gemd.iting |
| 票据前缀 | TAC | TIC |
| u16 来源 | cookie 里的设备 UUID | sha256("xmly-xuid:"+uid) |

## 配置：只要填账号

```bash
cp .env.example .env       # 把 xmly 换成你的 Cookie（每行一条）
./xmly-rush                # 直接跑一趟（无模式开关），跑完即退
```

像 `喜马拉雅.js` 一样，只认 `xmly`（多行；自动识别 Cookie / 账号#密码）：
也兼容 `XMLYOFF_CK` / `XMLYOFF_APP`，或同目录 `accounts.txt`。

其余全部内置，无需配置：

```text
放量窗口  0,8,12,16,20 点     抢单时长 90s
提前就绪  1.5s               提前发射 放量前 300ms 开火（请求正好卡在点上）
等到点    距整点 ≤3 分钟启动 → 等到点抢；刚过整点 ≤2 分钟 → 立刻补抢
串行补提  其余时段启动 → 逐号单发一次，不重试、不并发（对齐 kgw）
并发      6 协程/号（档位并发·优先最高）
提现档位  默认提「余额能覆盖的最高档」；多档同时抢，命中低档后再等 0.6s 看更高档
绑定筛查  启动先查绑定状态：没绑微信/支付宝的号不参与提现；每个窗口复查，绑好自动捡回
网络对时  开工即对表（NTP 式采样），放量前 30s 再对一次
平台变体  从 Cookie 自动识别（1&_device=android / iPhone）
状态文件  _state.json        提现票据 _wticket.txt / 签到票据 _ticket.txt（可选）
```

跑法：**无模式** —— 按时间自动决定（见上），青龙 cron 建议
`59 23,7,11,15,19 * * *`（点前 1 分钟拉起即可，点后 2 分钟内也认）
诊断：`-status`（看状态）/ `-dry`（只演算不发请求）/ `-only <uid>`（只跑一个号）
      `-probe`（每档各打一发 reserveQuota，看服务端真实返回）/ `-timesync`（看各时间源实测偏移）
      `-adprobe`（查各号的极速到账广告位）
自检：`-selftest`（x-tk 逐字节 / 签到签名与状态解析）
`XMLY_VERBOSE=1` 打印服务端原始响应。

## 提现记录与跨零点

成功提现后写入 `_state.json`（日期按**东八区**）：

```json
{
  "607197160": { "date": "2026-10-03", "amount": 1, "orderId": "...", "ts": 1791000000000 }
}
```

判重有两道闸，互相兜底：

1. **本地记录** —— 按 `note` 语义区分，只有确定结论才拦人：

   | `note` | 含义 | 是否跳过当天后续窗口 |
   | --- | --- | --- |
   | `ok` | 提现到账成功 | 是 |
   | `server-limit` | 服务端满额 **且已探测确认抢不到** | 是 |
   | `stale-reserve` | 抢到额度但提现失败（995 预占订单无效） | **否，继续抢** |

   到了第二天日期自然对不上，**自动重新参与**（不需要人工清理）。
2. **服务端口径** —— `withdrawConfig.todayWithdrawCount >= dailyWithdrawLimit` 时
   **先打一发 `reserveQuota` 探测**，确认真的抢不到才落 `server-limit` 跳过。
   0 点前后 10 分钟（跨日边界）服务端翻日慢，这段时间**不认**该计数，一律照抢。

### ⚠️ 为什么不能直接信 `todayWithdrawCount`

这个字段统计的是**提现受理数**，不是**到账数**。实测（2026-10-23，`-probe`），
号 `607252933` 服务端报 `今日=1/1`，但所有已绑卡档位 `reserveQuota` 全部
`ret=0` 正常返回 orderId —— 额度照样抢得到。

预占单一旦生成就计入额度，而提现失败后预占单**没被服务端回收**，计数就虚高了。
拿它当硬闸会白扔一整个放量窗口 —— 这正是「上一时段没提成功，下一段就被标记跳过」的成因。

另一个坑：额度虽然抢得到，但 `withdraw` 仍可能被服务端独立拦成
`995 今日提现次数已达上限`。这种号只能等次日额度翻日，程序不会反复空转。

旧记录超过 7 天自动清理。

## 提现通知

提现成功会立刻推一条（`notify.go`，移植自 `go-scripts/pkg/utils/notify.go`，入口 `Send(title, content)`）：
标题是「喜马拉雅提现成功 · N元」，正文含账号 / 金额 / 渠道 / orderId / 余额 / 时间。

同步发送（不另起协程）：这个号这一趟已经收工，阻塞只影响自己 —— 异步发送会被「跑完即退」掐掉。

通道全部读环境变量，写进 `.env` 即可，多通道可同时开；一个都没配就只在日志里打印：

| 通道 | 环境变量 |
| --- | --- |
| Bark（iOS） | `BARK_PUSH`（可选 `BARK_GROUP` / `BARK_SOUND` / `BARK_ICON` / `BARK_ARCHIVE`） |
| 钉钉机器人 | `DD_BOT_TOKEN` + `DD_BOT_SECRET` |
| 飞书机器人 | `FSKEY` |
| 企业微信机器人 | `QYWX_KEY` |
| 企业微信应用 | `QYWX_AM`（`corpid,corpsecret,touser,agentid[,mediaId]`） |
| Telegram | `TG_BOT_TOKEN` + `TG_USER_ID`（可选 `TG_API_HOST` 反代） |
| Server 酱 | `PUSH_KEY` |
| PushPlus | `PUSH_PLUS_TOKEN`（可选 `PUSH_PLUS_USER`） |
| PushDeer | `DEER_KEY` |
| wxpusher | `WX_PUSHER_TOKEN` + `WX_PUSHER_UID` |
| gotify | `GOTIFY_URL` + `GOTIFY_TOKEN` |
| NTQQ（CHRONOCAT） | `NT_QQ_URL` + `NT_QQ`（`user_id=..&group_id=..`，可选 `NT_QQ_TOKEN`） |

`CONSOLE` 默认开：console 通道会把「标题 + 正文」原样打进日志，不想要就在 `.env` 里写 `CONSOLE=0`。

发到哪个号是看**每笔提现**（不是每趟任务）：串行补提现时每个成功的号各推一条。

## 抢额度设计

1. 预热：先拉 `withdrawConfig` 挑候选档位，把每档的 AES + RSA 信封都算好
   （放量瞬间只剩一次 MD5 签名）。
2. 选档：候选 = **已绑卡 + 金额 ≤ 余额**，按「高→低」排序（默认提余额能覆盖的最高档）。
   没绑微信/支付宝的号在启动筛查时就被排开，不浪费任何请求。
3. 对时：`waitUntil` 最后 2 秒切 1ms 轮询，保证放量瞬间就位。
4. 提前 300ms 开火：6 个协程按「最高档拿一半、其余均分」猛打 `reserveQuota`，
   第一波请求正好落在放量瞬间；命中低档后再等 0.6s —— 更高档若同样命中就升档。
5. 按服务端返回分类（`-probe` 实测）：

   | 返回 | 含义 | 动作 |
   | --- | --- | --- |
   | `21112 暂不支持` | 无需预占 | 直接提现 |
   | `995 今日额度已抢完` | 正常竞争 | 继续猛冲 |
   | `995 余额不足` | 该档死掉 | 放弃该档 |
   | 登录/鉴权类 | 账号异常 | 整号停手 |

6. 成交即提现：带 `quotaOrderId` 发 `withdraw`，成功后回读余额；收工打印过程统计。
7. 多账号各自一个协程，互不排队。

额度是限量秒杀，0/8/12/16/20 点整点放量，先到先得。

## 提现模式：普通 / 极速（XMLY_MODE）

两种模式**共用同一套蹲点抢额度流程**（放量窗口、reserveQuota、档位选择完全不变），
区别只在**到账速度**，由提现前的广告上报决定（依据：正式版 9.5.13 抓包 + RN bundle
`useWithdrawFlow`）：

| 项 | 普通（normal，默认） | 极速（speed） |
| --- | --- | --- |
| 抢额度 / 提现请求 | 完全一致 | 完全一致（withdraw 不带任何模式字段） |
| 提现前广告上报 | 无 | `withdrawCashAd` × 3（`{"adId":广告位id,"type":1}`） |
| 官方客户端表现 | 看 1 个广告 | 看 3 个广告，页角「预计 30 分钟到账」 |
| 详情页状态 | 提现成功（预计 48 小时） | 提现加速成功（5 分钟内延时提示） |

```bash
XMLY_MODE=speed   # .env 里加一行即可；缺省 / normal = 普通到账
```

极速模式提现前会自动：查广告位（`queryWithdrawAdPosition`，`-adprobe` 可单查）→
连报 3 次 `withdrawCashAd` → 再发 `withdraw`。上报失败会降级为普通到账（打日志），
不会卡住提现主流程。

```text
XMLY_WD_RETRY=10        # withdraw 返回 21111（处理中）时的重试次数，官方客户端为 60
XMLY_COMBINED_CASH=1    # withdraw 带 supportCombinedCashBalance:true（对齐 iOS 正式版，默认不带）
```

## 网络对时

额度是**整点秒杀**，本机时钟偏几百毫秒就错过首波。开工先对表（`-timesync` 可单看）：

* 采样两个公开毫秒时间源（京东支付 / 淘宝），每轮记 t0/t1，
  偏移 = (服务端时间 + RTT/2) − t1，多轮取 **RTT 最小**的样本；
* 等待窗用对时后的时钟：最后 2 秒切 1ms 轮询，放量前 30s 再对一次表；
* 对时结果同样作用于 `x-timestamp` / 签名 / 日期判定（都跟服务端走）。

实测本机时钟慢 ~870ms，对表之后整点判定才靠谱。

## 边界：主流程只做提现

跑任务、扫码绑微信都不在这份工具里；0 点提现前的签到检查是唯一例外：

* 绑微信（提现渠道）→ `main.py` WebUI「生成绑定二维码」（或 `dev/pay/` 下的脚本）；
* 金币任务 → App。

本工具负责：档位放量时**抢额度 → 0 点签到检查 → 提交提现 → 记录状态**。
没绑卡的号会直接跳过并提示，绑完卡再跑即可（无需改配置）。

## 自检

```bash
go run . -selftest
# x-tk 自检: MATCH = true
```
